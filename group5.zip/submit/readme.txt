
run the `attentionRNN_bi.py` with the same command line argument.
run the `attentionRNN_driver.py` with the same command line argument.